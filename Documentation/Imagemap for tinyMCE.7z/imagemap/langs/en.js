tinyMCE.addI18n('en.imagemap_dlg',{
    "imgUrl":"Chose image",
    "dialog_title":"Image Mapping",
    "ok":"Ok",
    "src":"Image URL:",
    "alt":"Image Description:",
    "title":"Image Title:",
    "mapName":"Map Name:",
    "rectangle":"Rectangle",
    "polygon":"Polygon",
    "circle":"Circle",
    "preview":"Preview",
    "clear":"Clear",
    "load":"Load Image",
    "map_image":"Map Image",
    "errorSVG":"Your browser doesn't support this application. You need one of those browsers: Internet Explorer 9+, Google Chrome 3.0+, Safari 4.0+, Mozilla Firefox 1.5+, Opera 8.0+."
});